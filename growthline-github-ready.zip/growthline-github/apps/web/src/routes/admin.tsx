import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { Activity, ArrowDownRight, ArrowUpRight, Bell, CalendarDays, ChevronDown, ChevronLeft, ChevronRight, CircleHelp, Command, CreditCard, Download, Eye, FileText, Filter, Globe2, LayoutDashboard, LogOut, Megaphone, MoreHorizontal, Plus, Search, Settings, ShoppingBag, Sparkles, Target, Users, X } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import requireAuth from '@/lib/require-auth';

export const clientLoader = () => ({ user: requireAuth('/admin/login') });
clientLoader.hydrate = true as const;
export function HydrateFallback() { return <div className="admin-loading"><span className="admin-loader" />Loading workspace…</div>; }

const navGroups = [
  { label: 'WORKSPACE', items: [{ name: 'Overview', icon: LayoutDashboard }, { name: 'Analytics', icon: Activity }, { name: 'Campaigns', icon: Megaphone }, { name: 'Clients', icon: Users }] },
  { label: 'MANAGE', items: [{ name: 'Services', icon: ShoppingBag }, { name: 'Reports', icon: FileText }, { name: 'Billing', icon: CreditCard }] },
];
const campaigns = [
  { name: 'Summer launch — Meta Ads', client: 'Northstar Goods', channel: 'Meta Ads', spend: '$4,280', roas: '4.8x', status: 'Active', initials: 'NG', color: 'violet' },
  { name: 'Non-brand search growth', client: 'Forma Living', channel: 'Google Ads', spend: '$3,640', roas: '3.9x', status: 'Active', initials: 'FL', color: 'orange' },
  { name: 'New customer acquisition', client: 'Sunday Supply', channel: 'Paid Social', spend: '$2,190', roas: '3.4x', status: 'Learning', initials: 'SS', color: 'green' },
  { name: 'Retargeting — Q4', client: 'Aster & Co.', channel: 'Meta Ads', spend: '$1,760', roas: '5.2x', status: 'Active', initials: 'AC', color: 'blue' },
];
const chartValues = [34, 42, 38, 52, 47, 59, 54, 69, 63, 74, 68, 86, 77, 91, 82, 100, 89, 108, 97, 116, 108, 126, 119, 138];

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [active, setActive] = useState('Overview');
  const [period, setPeriod] = useState('Last 30 days');
  const [query, setQuery] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const filtered = useMemo(() => campaigns.filter(c => `${c.name} ${c.client} ${c.channel}`.toLowerCase().includes(query.toLowerCase())), [query]);
  const signOut = () => { logout(); navigate('/admin/login'); };
  return <div className="admin-shell">
    <aside className="admin-sidebar">
      <Link to="/" className="admin-brand"><span className="brand-mark">g<span>.</span></span><span>growthline<small>ADMIN WORKSPACE</small></span></Link>
      <div className="workspace-switch"><div className="workspace-avatar">G</div><div><strong>Growthline Studio</strong><small>Agency workspace</small></div><ChevronDown size={15}/></div>
      <div className="admin-nav">{navGroups.map(group => <div className="nav-group" key={group.label}><p>{group.label}</p>{group.items.map(item => <button key={item.name} className={`nav-link ${active === item.name ? 'selected' : ''}`} onClick={() => setActive(item.name)}><item.icon size={17}/><span>{item.name}</span>{item.name === 'Reports' && <span className="nav-count">4</span>}</button>)}</div>)}</div>
      <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><CircleHelp size={17}/></div><strong>Need a hand?</strong><p>Visit the help centre for tips and support.</p><button onClick={() => setActive('Help centre')}>Get support <span>↗</span></button></div><button className="nav-link" onClick={() => setActive('Settings')}><Settings size={17}/>Settings</button><div className="sidebar-user"><div className="user-avatar">{(user?.email?.[0] || 'A').toUpperCase()}</div><div className="user-info"><strong>{user?.email?.split('@')[0] || 'Admin'}</strong><small>{user?.email || 'Administrator'}</small></div><button title="Sign out" onClick={signOut}><LogOut size={16}/></button></div></div>
    </aside>
    <main className="admin-main">
      <header className="admin-topbar"><div className="breadcrumbs"><span>Workspace</span><span>/</span><strong>{active}</strong></div><div className="topbar-actions"><div className="admin-search"><Search size={15}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search anything…"/><kbd>⌘ K</kbd></div><div className="popover-wrap"><button className="icon-button" onClick={() => setShowNotifications(!showNotifications)} aria-label="Notifications"><Bell size={18}/><i/></button>{showNotifications && <div className="popover-panel"><strong>Notifications</strong><p className="notice-item"><span className="notice-dot"/>Weekly performance report is ready.<small>12 minutes ago</small></p><p className="notice-item"><span className="notice-dot muted"/>New client enquiry received.<small>Yesterday</small></p></div>}</div><div className="popover-wrap"><button className="top-user" onClick={() => setShowProfile(!showProfile)}><span className="user-avatar">{(user?.email?.[0] || 'A').toUpperCase()}</span><ChevronDown size={14}/></button>{showProfile && <div className="popover-panel profile-panel"><strong>{user?.email || 'Admin'}</strong><button onClick={signOut}><LogOut size={14}/> Sign out</button></div>}</div></div></header>
      <div className="admin-content">
        {active === 'Overview' ? <>
          <div className="page-heading"><div><div className="eyebrow"><Sparkles size={13}/> YOUR PERFORMANCE, AT A GLANCE</div><h1>Good evening<span>.</span></h1><p>Here’s what’s happening across your workspace today.</p></div><div className="heading-actions"><button className="outline-button" onClick={() => window.print()}><Download size={15}/> Export</button><button className="primary-button" onClick={() => setActive('Campaigns')}><Plus size={16}/> New campaign</button></div></div>
          <div className="overview-toolbar"><div className="live-indicator"><span/> LIVE OVERVIEW <span className="updated">Updated just now</span></div><button className="period-select" onClick={() => setPeriod(period === 'Last 30 days' ? 'Last 7 days' : period === 'Last 7 days' ? 'This quarter' : 'Last 30 days')}><CalendarDays size={15}/>{period}<ChevronDown size={14}/></button></div>
          <section className="metric-grid">
            <Metric title="Total revenue" value="$284,590" change="18.6%" positive detail="vs. previous period" icon={<CreditCard size={17}/>} spark={[22,29,24,36,31,43,39,52]}/>
            <Metric title="Ad spend" value="$42,860" change="8.2%" positive detail="vs. previous period" icon={<Target size={17}/>} spark={[27,23,31,29,37,33,42,45]}/>
            <Metric title="ROAS" value="4.82x" change="12.4%" positive detail="vs. previous period" icon={<Activity size={17}/>} spark={[18,25,23,34,31,39,43,51]}/>
            <Metric title="Active clients" value="18" change="2 new" positive detail="this month" icon={<Users size={17}/>} spark={[20,20,25,25,32,32,38,45]}/>
          </section>
          <section className="dashboard-grid">
            <div className="panel performance-panel"><div className="panel-heading"><div><h2>Performance overview</h2><p>Revenue generated across all active campaigns</p></div><button className="more-button" onClick={() => setActive('Analytics')}><MoreHorizontal size={19}/></button></div><div className="chart-summary"><strong>$284,590</strong><span className="positive-text"><ArrowUpRight size={14}/> 18.6%</span><small>Revenue</small></div><div className="chart-wrap"><div className="chart-ylabels"><span>$150k</span><span>$100k</span><span>$50k</span><span>$0</span></div><svg viewBox="0 0 700 190" preserveAspectRatio="none" className="revenue-chart" role="img" aria-label="Revenue trending upward over the last 30 days"><defs><linearGradient id="areaFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#7967ee" stopOpacity=".22"/><stop offset="100%" stopColor="#7967ee" stopOpacity="0"/></linearGradient></defs>{[15,65,115,165].map(y=><line key={y} x1="0" y1={y} x2="700" y2={y} stroke="#ececf2" strokeDasharray="4 5"/>)}<path d={`M ${chartValues.map((v,i)=>`${i*30},${165-v}`).join(' L ')} L 690,190 L 0,190 Z`} fill="url(#areaFill)"/><path d={`M ${chartValues.map((v,i)=>`${i*30},${165-v}`).join(' L ')}`} fill="none" stroke="#7967ee" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke"/></svg></div><div className="chart-xlabels"><span>Oct 14</span><span>Oct 21</span><span>Oct 28</span><span>Nov 4</span><span>Nov 12</span></div><div className="chart-legend"><span><i className="legend-dot purple"/> Revenue</span><span><i className="legend-dot grey"/> Previous period</span></div></div>
            <div className="panel channel-panel"><div className="panel-heading"><div><h2>Channel mix</h2><p>Revenue by acquisition channel</p></div><button className="more-button" onClick={() => setActive('Analytics')}><MoreHorizontal size={19}/></button></div><div className="donut-area"><div className="donut"><div><strong>284.6k</strong><small>Total revenue</small></div></div></div><div className="channel-legend"><Channel color="purple" label="Meta Ads" value="$119,528" percent="42%"/><Channel color="orange" label="Google Ads" value="$88,223" percent="31%"/><Channel color="blue" label="Organic" value="$48,380" percent="17%"/><Channel color="grey" label="Other" value="$28,459" percent="10%"/></div></div>
          </section>
          <section className="panel campaigns-panel"><div className="panel-heading campaign-heading"><div><h2>Campaign performance</h2><p>Monitor your top-performing campaigns</p></div><div className="table-actions"><button className="outline-button small" onClick={() => setQuery('')}><Filter size={14}/> Filter</button><button className="text-button" onClick={() => setActive('Campaigns')}>View all <ChevronRight size={15}/></button></div></div><div className="table-scroll"><table className="campaign-table"><thead><tr><th>CAMPAIGN / CLIENT</th><th>CHANNEL</th><th>SPEND</th><th>ROAS</th><th>STATUS</th><th/></tr></thead><tbody>{filtered.map(c=><tr key={c.name}><td><div className="campaign-name"><span className={`client-avatar ${c.color}`}>{c.initials}</span><span><strong>{c.name}</strong><small>{c.client}</small></span></div></td><td>{c.channel}</td><td className="table-strong">{c.spend}</td><td className="table-strong">{c.roas}</td><td><span className={`status-pill ${c.status === 'Active' ? 'active' : 'learning'}`}><i/>{c.status}</span></td><td><button className="more-button"><MoreHorizontal size={17}/></button></td></tr>)}</tbody></table>{filtered.length === 0 && <div className="empty-state">No campaigns match “{query}”.</div>}</div></section>
          <div className="bottom-grid"><section className="panel activity-panel"><div className="panel-heading"><div><h2>Recent activity</h2><p>Latest updates from your workspace</p></div><button className="text-button" onClick={() => setActive('Reports')}>See all <ChevronRight size={15}/></button></div><ActivityRow icon={<FileText size={15}/>} title="Monthly report generated" detail="Northstar Goods · Performance report" time="12 min ago"/><ActivityRow icon={<Users size={15}/>} title="New client added" detail="Aster & Co. · Client workspace" time="2 hours ago"/><ActivityRow icon={<Megaphone size={15}/>} title="Campaign status updated" detail="Sunday Supply · Learning phase" time="Yesterday"/></section><section className="growth-card"><div className="growth-icon"><Sparkles size={18}/></div><span className="growth-label">GROWTH TIP</span><h2>Small optimisations.<br/>Big outcomes.</h2><p>Campaigns with weekly creative refreshes see stronger engagement. Review your top ads this week.</p><button onClick={() => setActive('Campaigns')}>Review campaigns <ArrowUpRight size={15}/></button><div className="growth-decoration">✳</div></section></div>
        </> : <div className="section-placeholder"><div className="placeholder-icon"><Command size={22}/></div><span className="eyebrow">GROWTHLINE WORKSPACE</span><h1>{active}<span>.</span></h1><p>This section is ready for your workflow. Your overview dashboard is available anytime.</p><button className="primary-button" onClick={() => setActive('Overview')}><LayoutDashboard size={15}/> Back to overview</button></div>}
        <footer className="admin-footer"><span>© 2026 Growthline Studio</span><span>Made for measurable growth <span className="footer-heart">✳</span></span><span>v1.0.0</span></footer>
      </div>
    </main>
  </div>;
}

function Metric({ title, value, change, positive, detail, icon, spark }: { title:string; value:string; change:string; positive:boolean; detail:string; icon:React.ReactNode; spark:number[] }) {
  const points = spark.map((v,i)=>`${i*12},${50-v}`).join(' ');
  return <div className="metric-card"><div className="metric-top"><span>{title}</span><span className="metric-icon">{icon}</span></div><div className="metric-value">{value}</div><div className="metric-bottom"><span className={`metric-change ${positive?'up':'down'}`}>{positive?<ArrowUpRight size={13}/>:<ArrowDownRight size={13}/>} {change}</span><span>{detail}</span></div><svg className="metric-spark" viewBox="0 0 84 54" preserveAspectRatio="none"><polyline points={points} fill="none" stroke="#8b7cf0" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg></div>;
}
function Channel({color,label,value,percent}:{color:string;label:string;value:string;percent:string}) { return <div className="channel-row"><span className={`legend-dot ${color}`}/><span className="channel-name">{label}</span><strong>{value}</strong><small>{percent}</small></div>; }
function ActivityRow({icon,title,detail,time}:{icon:React.ReactNode;title:string;detail:string;time:string}) { return <div className="activity-row"><span className="activity-icon">{icon}</span><div><strong>{title}</strong><small>{detail}</small></div><time>{time}</time></div>; }
