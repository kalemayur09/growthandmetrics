import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { ArrowRight, Eye, EyeOff, LockKeyhole, Mail, ShieldCheck } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

export default function AdminLogin() {
  const { login, isAuthed, isLoading } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (isAuthed && !isLoading) navigate('/admin', { replace: true }); }, [isAuthed, isLoading, navigate]);
  const submit = async (e: React.FormEvent) => { e.preventDefault(); setError(''); setBusy(true); try { await login(email.trim(), password); navigate('/admin', { replace: true }); } catch { setError('Unable to sign in. Check your email and password, then try again.'); } finally { setBusy(false); } };
  return <div className="admin-login-shell"><div className="login-visual"><Link to="/" className="admin-brand login-brand"><span className="brand-mark">g<span>.</span></span><span>growthline<small>PERFORMANCE STUDIO</small></span></Link><div className="login-visual-copy"><span className="eyebrow">THE GROWTHLINE WORKSPACE</span><h1>Make every<br/>move <em>count.</em></h1><p>Your performance, clients and campaigns — all in one place.</p><div className="login-visual-foot"><span><ShieldCheck size={15}/> Private & secure workspace</span><span>01 — 03</span></div></div><div className="login-orbit orbit-one"/><div className="login-orbit orbit-two"/><div className="login-grid-art"/></div><div className="login-form-side"><div className="login-form-wrap"><div className="mobile-login-brand"><span className="brand-mark">g<span>.</span></span> growthline</div><span className="eyebrow">WELCOME BACK</span><h2>Sign in to your<br/>workspace<span>.</span></h2><p className="login-intro">Enter your credentials to access your dashboard.</p><form onSubmit={submit}><label htmlFor="admin-email">Email address</label><div className="login-input"><Mail size={17}/><input id="admin-email" type="email" autoComplete="username" placeholder="you@company.com" value={email} onChange={e=>setEmail(e.target.value)} required/></div><label htmlFor="admin-password">Password</label><div className="login-input"><LockKeyhole size={17}/><input id="admin-password" type={showPassword?'text':'password'} autoComplete="current-password" placeholder="Enter your password" value={password} onChange={e=>setPassword(e.target.value)} required/><button type="button" onClick={()=>setShowPassword(!showPassword)} aria-label={showPassword?'Hide password':'Show password'}>{showPassword?<EyeOff size={17}/>:<Eye size={17}/>}</button></div>{error && <div className="login-error">{error}</div>}<button className="login-submit" type="submit" disabled={busy || isLoading}>{busy?'Signing in…':'Sign in'} <ArrowRight size={17}/></button></form><div className="login-security"><ShieldCheck size={15}/> Protected access for authorised team members</div><Link to="/" className="back-site">← Back to website</Link></div><div className="login-copyright">© 2026 Growthline Studio. All rights reserved.</div></div></div>;
}
