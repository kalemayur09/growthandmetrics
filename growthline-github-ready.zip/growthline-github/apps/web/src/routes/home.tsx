import type { Route } from './+types/home';
import { seo } from '@/lib/seo';
import { SiteHeader } from '@/components/site-header';
import { Hero } from '@/components/home/hero';
import { Results } from '@/components/home/results';
import { Services } from '@/components/home/services';
import { Approach } from '@/components/home/approach';
import { Pricing } from '@/components/home/pricing';
import { Testimonials } from '@/components/home/testimonials';
import { Audit } from '@/components/home/audit';
import { Faq } from '@/components/home/faq';
import { SiteFooter } from '@/components/site-footer';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'Growthline | E-commerce Performance Marketing in Miami',
    description: 'Less guesswork. More growth. Growthline connects paid social, Google Ads, and conversion rate optimisation for e-commerce brands. Request your free marketing audit.',
    jsonLd: { '@context': 'https://schema.org', '@type': 'ProfessionalService', name: 'Growthline', description: 'E-commerce performance marketing agency specialising in paid social, Google Ads and conversion rate optimisation.', address: { '@type': 'PostalAddress', addressLocality: 'Miami', addressRegion: 'FL', addressCountry: 'US' }, areaServed: 'Worldwide' },
  });
}

export default function HomePage() {
  return <><a className="skip-link" href="#main">Skip to content</a><SiteHeader /><main id="main"><Hero /><div className="channel-strip"><span>BUILT FOR E-COMMERCE.</span><span>POWERED BY DATA.</span><span>DRIVEN BY CREATIVE.</span><span>MEASURED IN GROWTH.<span className="strip-arrow">↗</span></span></div><Results /><Services /><Approach /><Pricing /><Testimonials /><Audit /><Faq /></main><SiteFooter /></>;
}
