import { ArrowDown, ArrowUpRight, TrendingUp } from 'lucide-react';

export function Hero() {
  return (
    <section id="top" className="hero">
      <div className="hero-grid" aria-hidden="true" />
      <div className="hero-topline"><span className="eyebrow"><span className="status-dot" /> MIAMI ROOTS. GLOBAL GROWTH.</span><span className="hero-coordinate">25.7617° N / 80.1918° W</span></div>
      <h1>LESS GUESSWORK.<br /><span>MORE GROWTH.</span></h1>
      <div className="hero-bottom">
        <div className="hero-copy"><p>We turn clicks into customers.<br />Performance marketing for e-commerce<br className="desktop-break" /> brands ready for their next growth curve.</p><div className="hero-actions"><a href="#audit" className="button button-green">Find your growth opportunities <ArrowUpRight size={20} /></a><a className="text-link" href="#results">See the approach <ArrowUpRight size={16} /></a></div><div className="hero-specialties"><span>PAID SOCIAL</span><span>GOOGLE ADS</span><span>CRO</span></div></div>
        <div className="growth-visual" aria-label="Illustrative upward growth chart">
          <div className="chart-meta"><span><span className="status-dot" /> THE GROWTH MINDSET</span><TrendingUp size={19} /></div>
          <div className="chart-area"><div className="chart-y"><span>4×</span><span>3×</span><span>2×</span><span>1×</span></div><div className="chart-lines" /><svg viewBox="0 0 490 170" preserveAspectRatio="none" role="img" aria-label="Conceptual performance growth curve"><defs><linearGradient id="chart-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#B6FF3B" stopOpacity=".2" /><stop offset="100%" stopColor="#B6FF3B" stopOpacity="0" /></linearGradient></defs><path d="M 0 158 L 48 148 L 89 151 L 126 122 L 168 126 L 212 101 L 257 111 L 298 65 L 339 71 L 375 46 L 414 49 L 455 15 L 490 0 L 490 170 L 0 170 Z" fill="url(#chart-fill)" /><path d="M 0 158 L 48 148 L 89 151 L 126 122 L 168 126 L 212 101 L 257 111 L 298 65 L 339 71 L 375 46 L 414 49 L 455 15 L 490 0" fill="none" stroke="#B6FF3B" strokeWidth="3" vectorEffect="non-scaling-stroke" /></svg></div><div className="chart-footer"><span>TEST. LEARN. OPTIMISE. SCALE.</span><span>CONCEPTUAL VISUAL</span></div>
          <div className="chart-sticker"><ArrowUpRight size={23} /><span>Built for<br /><strong>what’s next.</strong></span></div>
        </div>
      </div>
      <div className="hero-foot"><a href="#results"><ArrowDown size={15} /> SCROLL TO EXPLORE</a><span>YOUR GROWTH. OUR OBSESSION.</span></div>
    </section>
  );
}
