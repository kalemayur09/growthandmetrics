import { ArrowUpRight, Quote } from 'lucide-react';
import { testimonials } from '@/data/growthline';

export function Testimonials() {
  return <section className="testimonials-section section-pad" aria-labelledby="testimonials-heading"><div className="testimonial-intro"><div className="eyebrow"><span className="section-index">05 /</span> A REAL PARTNERSHIP</div><h2 id="testimonials-heading">More than<br />an agency.<br /><span className="muted-heading">An extension<br />of your team.</span></h2><a href="#audit" className="text-link">Meet your next growth partner <ArrowUpRight size={17} /></a></div><div className="testimonial-list">{testimonials.map(item => <figure key={item.initials}><Quote size={29} className="quote-icon" strokeWidth={1.3} /><blockquote>{item.quote}</blockquote><figcaption><span className="testimonial-avatar">{item.initials}</span><div><strong>{item.role}</strong><span>{item.category}</span></div><span className="sample-label">SAMPLE QUOTE</span></figcaption></figure>)}<p className="disclosure">Illustrative testimonials shown for layout. Approved client quotes will replace these examples.</p></div></section>;
}
