import { ArrowUpRight } from 'lucide-react';
import { caseStudies } from '@/data/growthline';
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

export function Results() {
  return (
    <section id="results" className="results-section section-pad">
      <div className="section-heading"><div><div className="eyebrow"><span className="section-index">01 /</span> THE WORK, NOT THE HYPE</div><h2>Big ambitions.<br /><span className="muted-heading">Measurable moves.</span></h2></div><p>Every brand has a different growth equation.<br />Here’s what a focused strategy can look like.</p></div>
      <div className="case-grid">{caseStudies.map(study => <Dialog key={study.id}><article className="case-card"><DialogTrigger asChild><button className="case-image-button" aria-label={`Explore the ${study.brand} illustrative case study`}><img src={study.image} alt={study.alt} loading="lazy" /><span className="case-brand">{study.brand}<small>{study.category}</small></span><span className="case-open"><ArrowUpRight size={23} /></span><span className="image-badge">ILLUSTRATIVE CASE STUDY</span></button></DialogTrigger><div className="case-tags">{study.tags.map(tag => <span key={tag}>{tag}</span>)}</div><h3>{study.title}</h3><div className="case-metrics"><div><strong>{study.metric}</strong><span>{study.metricLabel}</span></div><div><strong>{study.secondary}</strong><span>{study.secondaryLabel}</span></div><DialogTrigger asChild><button className="circle-link" aria-label={`Read ${study.brand} strategy`}><ArrowUpRight size={23} /></button></DialogTrigger></div></article><DialogContent className="case-dialog"><span className="eyebrow">ILLUSTRATIVE CASE STUDY / {study.category}</span><DialogTitle className="dialog-title">{study.brand}: {study.title}</DialogTitle><DialogDescription>Example strategy and demonstration figures. Not a verified client engagement.</DialogDescription><img src={study.image} alt={study.alt} className="dialog-image" /><div><h4>The challenge</h4><p>{study.challenge}</p></div><div><h4>The strategy</h4><p>{study.approach}</p></div><div><h4>The modelled outcome</h4><p>{study.outcome}</p></div><DialogClose asChild><a href="#audit" className="text-link">Explore your growth opportunities <ArrowUpRight size={17} /></a></DialogClose></DialogContent></Dialog> )}</div>
      <p className="disclosure">The case studies above are illustrative examples. Brands and metrics are demonstration content, not verified client results.</p>
    </section>
  );
}
