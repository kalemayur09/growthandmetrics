import { Plus } from 'lucide-react';
import { faqs } from '@/data/growthline';

export function Faq() {
  return <section className="faq-section section-pad"><div><div className="eyebrow">A LITTLE MORE CLARITY</div><h2>Good questions.<br />Straight answers.</h2></div><div className="faq-list">{faqs.map(faq => <details key={faq.question}><summary>{faq.question}<Plus size={19} /></summary><p>{faq.answer}</p></details>)}</div></section>;
}
