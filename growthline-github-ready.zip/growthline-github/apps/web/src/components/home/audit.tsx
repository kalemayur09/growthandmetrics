import { useState, type FormEvent } from 'react';
import { ArrowUpRight, Check, CheckCircle2, Loader2, LockKeyhole } from 'lucide-react';
import { pocketbaseClient } from '@/lib/pocketbase-client';

const serviceOptions = ['Paid social', 'Google Ads', 'Conversion optimisation', 'Full growth strategy'];
const spendOptions = ['Not running ads yet', 'Under $5,000', '$5,000–$20,000', '$20,000–$50,000', '$50,000–$100,000', '$100,000+'];

export function Audit() {
  const [selected, setSelected] = useState<string[]>([]);
  const [state, setState] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [error, setError] = useState('');
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (state === 'submitting') return;
    const form = event.currentTarget;
    const values = new FormData(form);
    setError('');
    if (values.get('website_trap')) { setError('Unable to submit this request. Please try again.'); return; }
    if (!selected.length) { setError('Please select at least one area you’d like us to review.'); return; }
    const fullName = String(values.get('full_name') || '').trim();
    if (fullName.length < 2) { setError('Please enter your full name.'); return; }
    setState('submitting');
    try {
      await pocketbaseClient.collection('audit_requests').create({ full_name: fullName, email: String(values.get('email') || '').trim(), store_url: String(values.get('store_url') || '').trim(), monthly_spend: values.get('monthly_spend'), services: selected, goals: String(values.get('goals') || '').trim(), consent: values.get('consent') === 'on', website_trap: '' });
      setState('success');
    } catch {
      setError('Your request couldn’t be saved. Please check your details and connection, then try again.');
      setState('idle');
    }
  }
  return <section id="audit" className="audit-section section-pad"><div className="audit-intro"><div className="eyebrow"><span className="section-index">06 /</span> LET’S FIND YOUR NEXT WIN</div><h2>YOUR NEXT<br />GROWTH CURVE<br /><span>STARTS HERE.</span></h2><p>Get a fresh set of eyes on your marketing. We’ll look for wasted spend, missed opportunities, and friction in your funnel.</p><ul className="audit-benefits"><li><Check size={17} /> Actionable opportunities, not a sales deck.</li><li><Check size={17} /> A cross-channel perspective.</li><li><Check size={17} /> Free. No obligation. No fluff.</li></ul><div className="audit-location"><span className="status-dot" /> BASED IN MIAMI. BUILT FOR YOUR AMBITION.</div></div><div className="audit-form-panel">{state === 'success' ? <div className="audit-success" role="status"><CheckCircle2 size={48} /><div className="eyebrow">REQUEST RECEIVED</div><h3>You’re on our radar.</h3><p>Your audit request has been saved. The Growthline team can now review your brand and follow up using the email you provided.</p><button type="button" className="button button-green" onClick={() => { setState('idle'); setSelected([]); }}>Submit another request <ArrowUpRight size={18} /></button></div> : <form onSubmit={submit}><div className="form-header"><h3>Request your free audit</h3><span>01 MIN TO GET STARTED</span></div><div className="form-two-col"><label className="form-field">Full name <input name="full_name" placeholder="Your full name" autoComplete="name" required minLength={2} maxLength={150} /></label><label className="form-field">Work email <input name="email" type="email" placeholder="you@yourbrand.com" autoComplete="email" required maxLength={254} /></label></div><label className="form-field">Your store URL <input name="store_url" type="url" placeholder="https://yourbrand.com" required maxLength={2000} /></label><label className="form-field">Monthly ad spend <select name="monthly_spend" required defaultValue=""><option value="" disabled>Select your current spend</option>{spendOptions.map(value => <option key={value}>{value}</option>)}</select></label><fieldset className="services-fieldset"><legend>Where do you want to grow?</legend><div className="service-options">{serviceOptions.map(option => <label key={option} className={selected.includes(option) ? 'is-selected' : ''}><input type="checkbox" name="service_interest" value={option} checked={selected.includes(option)} onChange={event => setSelected(event.target.checked ? [...selected, option] : selected.filter(item => item !== option))} />{option}</label>)}</div></fieldset><label className="form-field">What’s your biggest growth challenge? <span className="optional">(optional)</span><textarea name="goals" placeholder="Tell us where you are—and where you want to go." rows={3} maxLength={3000} /></label><div className="honeypot" aria-hidden="true"><label>Leave this field empty<input name="website_trap" tabIndex={-1} autoComplete="off" /></label></div><label className="consent-label"><input name="consent" type="checkbox" required /><span>I agree to Growthline using these details to review my request and contact me. <a href="#privacy">Privacy notice</a></span></label>{error && <p className="form-error" role="alert">{error}</p>}<button className="button button-green submit-button" disabled={state === 'submitting'} type="submit">{state === 'submitting' ? <>Saving your request <Loader2 className="animate-spin" size={18} /></> : <>Find my growth opportunities <ArrowUpRight size={20} /></>}</button><p className="form-security"><LockKeyhole size={12} /> Your details stay private. Never share account passwords.</p></form>}</div></section>;
}
