import { useState } from 'react';
import { ArrowUpRight, Check, Minus, Plus } from 'lucide-react';
import { services } from '@/data/growthline';

export function Services() {
  const [expanded, setExpanded] = useState('01');
  return <section id="services" className="services-section section-pad"><div className="services-intro"><div className="eyebrow"><span className="section-index">02 /</span> CONNECTED BY DESIGN</div><h2>Three levers.<br />One growth engine.</h2><p>Not isolated channels. A joined-up strategy that turns attention into action—and action into revenue.</p><a href="#audit" className="text-link">Let’s find your next lever <ArrowUpRight size={18} /></a></div><div className="service-list">{services.map(service => { const open = expanded === service.number; return <article className={`service-item ${open ? 'is-open' : ''}`} key={service.number}><button className="service-toggle" aria-expanded={open} aria-controls={`service-${service.number}`} onClick={() => setExpanded(open ? '' : service.number)}><span className="service-number">{service.number}</span><h3>{service.title}</h3><span className="service-toggle-icon">{open ? <Minus size={20} /> : <Plus size={20} />}</span></button><div className="service-content" id={`service-${service.number}`} hidden={!open}><h4>{service.tagline}</h4><p>{service.description}</p><ul>{service.items.map(item => <li key={item}><Check size={15} />{item}</li>)}</ul><span className="service-note">{service.metric}</span></div></article>; })}</div></section>;
}
