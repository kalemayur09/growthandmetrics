import { useState } from 'react';
import { ArrowUpRight, Menu, X } from 'lucide-react';

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="site-header">
      <a className="wordmark" href="#top" aria-label="Growthandmetrics home">growthandmetrics<span className="logo-mark" aria-hidden="true">↗</span></a>
      <nav className="desktop-nav" aria-label="Main navigation">
        <a href="#results">Our work</a><a href="#services">Services</a><a href="#approach">Our approach</a><a href="#pricing">Pricing</a>
      </nav>
      <a className="button button-green header-cta" href="#audit">Get a free audit <ArrowUpRight size={17} /></a>
      <button className="menu-toggle" type="button" onClick={() => setOpen(!open)} aria-expanded={open} aria-controls="mobile-menu" aria-label={open ? 'Close navigation' : 'Open navigation'}>{open ? <X /> : <Menu />}</button>
      {open && <nav id="mobile-menu" className="mobile-nav" aria-label="Mobile navigation">{[['Our work', 'results'], ['Services', 'services'], ['Our approach', 'approach'], ['Pricing', 'pricing'], ['Get a free audit', 'audit']].map(([label, id]) => <a key={id} href={`#${id}`} onClick={() => setOpen(false)}>{label}<ArrowUpRight size={18} /></a>)}</nav>}
    </header>
  );
}
