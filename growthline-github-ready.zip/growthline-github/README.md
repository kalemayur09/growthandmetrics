# Growthline Admin Dashboard

Admin dashboard project built with a Vite/React frontend and a PocketBase integration.

## Repository setup

This repository is prepared for GitHub. Do not commit real `.env` files, API keys, admin credentials, or database secrets.

## Requirements

- Node.js (use the version supported by the project dependencies)
- npm or Bun
- PocketBase service configured separately for authentication/data features

## Install

```bash
npm install
```

If you use Bun and the included lockfile:

```bash
bun install
```

## Run locally

Check the scripts in the root `package.json` and `apps/web/package.json`. The root development script expects the PocketBase app workspace to be present and configured.

## Build

```bash
npm run build
```

## Environment configuration

Configure the required environment variables in your deployment platform. Never commit production secrets. Review `ADMIN_SETUP.md` for project-specific setup notes.

## Deployment

Build and deploy the frontend using a hosting provider that supports Vite/React static output or Node.js applications, depending on the configured app scripts. Run PocketBase as a separate backend service unless your hosting architecture explicitly supports it.
