# Growthline Admin Dashboard

## Routes
- `/admin/login` — sign-in screen using the existing PocketBase `users` authentication collection.
- `/admin` — authenticated dashboard workspace.

## Included in this build
- Responsive admin navigation and dashboard shell.
- Revenue, ad spend, ROAS and active-client KPI cards.
- Revenue trend and channel mix visualisations.
- Campaign table with live client-side search.
- Recent activity, notification popover, export-to-print action and sign-out.
- Placeholder navigation for Analytics, Campaigns, Clients, Services, Reports, Billing and Settings.

## Important production setup
The KPI, campaign and activity values in this first dashboard are demonstration data; they are not connected to live analytics or client records yet. The sign-in uses the project's existing PocketBase `users` authentication collection. Before publishing, restrict the PocketBase collection/API rules so only authorised administrator accounts can access the admin area. The current route guard checks for an authenticated user session, not an administrator role, because the exported project does not define an admin-role field or permissions schema.

To connect live data, define the required PocketBase collections (for example `clients`, `campaigns`, `daily_metrics`, and `activity_logs`) and their access rules, then replace the sample arrays in `src/routes/admin.tsx` with authenticated data loaders/actions.
